package io.avec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityLdapWithDbAuthorizationMasterMysqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
